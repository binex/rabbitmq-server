## The contents of this file are subject to the Mozilla Public License
## Version 1.1 (the "License"); you may not use this file except in
## compliance with the License. You may obtain a copy of the License
## at http://www.mozilla.org/MPL/
##
## Software distributed under the License is distributed on an "AS IS"
## basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
## the License for the specific language governing rights and
## limitations under the License.
##
## The Original Code is RabbitMQ.
##
## The Initial Developer of the Original Code is GoPivotal, Inc.
## Copyright (c) 2007-2017 Pivotal Software, Inc.  All rights reserved.


defmodule SetVhostLimitsCommandTest do
  use ExUnit.Case, async: false
  import TestHelper

  @command RabbitMQ.CLI.Ctl.Commands.SetVhostLimitsCommand

  @vhost "test1"
  @definition "{\"max-connections\":100}"

  setup_all do
    RabbitMQ.CLI.Core.Distribution.start()


    add_vhost @vhost

    on_exit([], fn ->
      delete_vhost @vhost


    end)

    :ok
  end

  setup context do

    vhost = context[:vhost] || @vhost

    clear_vhost_limits(vhost)

    on_exit(context, fn ->
      clear_vhost_limits(vhost)
    end)

    {
      :ok,
      opts: %{
        node: get_rabbit_hostname(),
        vhost: vhost
      },
      definition: context[:definition] || @definition,
      vhost: vhost
    }
  end

  test "merge_defaults: a well-formed command with no vhost runs against the default" do
    assert match?({_, %{vhost: "/"}}, @command.merge_defaults([], %{}))
  end

  test "merge_defaults: does not change defined vhost" do
    assert match?({[], %{vhost: "test_vhost"}}, @command.merge_defaults([], %{vhost: "test_vhost"}))
  end

  test "validate: providing too few arguments fails validation" do
    assert @command.validate([], %{}) == {:validation_failure, :not_enough_args}
  end

  test "validate: providing too many arguments fails validation" do
    assert @command.validate(["too", "many"], %{}) == {:validation_failure, :too_many_args}
    assert @command.validate(["is", "too", "many"], %{}) == {:validation_failure, :too_many_args}
    assert @command.validate(["this", "is", "too", "many"], %{}) == {:validation_failure, :too_many_args}
  end

  test "run: a well-formed, host-specific command returns okay", context do
    assert @command.run(
      [context[:definition]],
      context[:opts]
    ) == :ok

    assert_limits(context)
  end

  test "run: an unreachable node throws a badrpc" do
    target = :jake@thedog

    opts = %{node: target, vhost: "/"}

    assert @command.run([@definition], opts) == {:badrpc, :nodedown}
  end

  @tag vhost: "bad-vhost"
  test "run: providing a non-existent vhost reports an error", context do
    vhost_opts = Map.merge(context[:opts], %{vhost: context[:vhost]})

    assert @command.run(
      [context[:definition]],
      vhost_opts
    ) == {:error, {:no_such_vhost, context[:vhost]}}
  end

  test "run: an invalid definition returns a JSON decoding error", context do
    assert match?({:error_string, _},
      @command.run(["bad_value"], context[:opts]))

    assert get_vhost_limits(context[:vhost]) == %{}
  end

  test "run: invalid limit returns an error", context do
    assert @command.run(
      ["{\"foo\":\"bar\"}"],
      context[:opts]
    ) == {:error_string, 'Validation failed\n\nUnrecognised terms [{<<"foo">>,<<"bar">>}] in limits\n'}

    assert get_vhost_limits(context[:vhost]) == %{}
  end

  test "run: an empty JSON object definition unsets all limits for vhost", context do

    assert @command.run(
      [@definition],
      context[:opts]
    ) == :ok

    assert_limits(context)

    assert @command.run(
      ["{}"],
      context[:opts]
    ) == :ok

    assert get_vhost_limits(context[:vhost]) == %{}
  end

  test "banner", context do
    vhost_opts = Map.merge(context[:opts], %{vhost: context[:vhost]})

    assert @command.banner([context[:definition]], vhost_opts)
      == "Setting vhost limits to \"#{context[:definition]}\" for vhost \"#{context[:vhost]}\" ..."
  end

  defp assert_limits(context) do
    limits = get_vhost_limits(context[:vhost])
    assert {:ok, limits} == JSON.decode(context[:definition])
  end
end
