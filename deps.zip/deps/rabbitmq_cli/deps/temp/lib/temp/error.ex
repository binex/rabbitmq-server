defmodule Temp.Error do
  defexception message: "Could not make temp file"
end
